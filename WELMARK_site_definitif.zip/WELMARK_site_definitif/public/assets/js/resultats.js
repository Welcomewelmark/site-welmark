const etablissements = {
  "001": "Lycée Moderne",
  "002": "Collège Espoir",
  "003": "Institut Lumière",
  "004": "Complexe Savoir Plus",
  "005": "Académie du Succès",
  "006": "Centre WELMARK",
  "007": "Groupe Excellence",
  "008": "Institut Horizon",
  "009": "École du Progrès",
  "010": "Centre de Formation WELMARK"
  // Ajoute ici tous tes codes !
};

function rechercherEtablissement() {
  const code = document.getElementById('codeEtab').value.trim();
  const nomInput = document.getElementById('nomEtab');

  if (etablissements.hasOwnProperty(code)) {
    nomInput.value = etablissements[code];
  } else {
    nomInput.value = "";
  }
}